// Define count object in array
Object.defineProperties(Array.prototype, {
    count: {
        value: function(value) {
            return this.filter(x => x==value).length;
        }
    }
});

// Functions used

// Function to repeat: takes an array arr and repeats to the size of len (so want to use total_trials for the number of length)
function repeat(arr, len) {
    while (arr.length < len) arr = arr.concat(arr.slice(0, len-arr.length));
    return arr;
}


// Randomly shuffle the array
function shuffleArray(array, l) {
    for (var i = l - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array
}

function shuffle(arr1, arr2){
    "use strict";
    var l = arr1.length,
    i = 0,
    rnd,
    tmp1,
    tmp2;

    while (i < l) {
        rnd = Math.round(Math.random() * i)
        tmp1 = arr1[i]
        tmp2 = arr2[i]
        arr1[i] = arr1[rnd]
        arr2[i] = arr2[rnd]
        arr1[rnd] = tmp1
        arr2[rnd] = tmp2
        i += 1
    }
    return {array1: arr1, array2: arr2}
}

function cartesian(...args) {
    var r = [], max = args.length-1;
    function helper(arr, i) {
        for (var j=0, l=args[i].length; j<l; j++) {
            var a = arr.slice(0); // clone arr
            a.push(args[i][j]);
            if (i==max)
                r.push(a);
            else
                helper(a, i+1);
        }
    }
    helper([], 0);
    return r;
}

// FUNCTION: Convert points to monetary value
// Inputs: 
// Total_points: (integer) number of points the particpant earned
// Max_points: (integer) max number of points particpant could have earned
// Monetary Range: (2x1 vector) of lowest and highest amount of money to win possible
// Incentive Earnings: (2x1 vector) additional money won if above certain threshold
// Incentive Points: (2x1 vector) thresholds needed to win incentive earnings
// Total_incentives: integer of the number possible incentives. This is equivalent to the length of the incentive earnings array and points array
// Output: Vector [Monetary amount of points won, incentive won, incentive + money won, threshold passed to win points]
function convert_monetary_value(total_points, max_points, monetary_range){
    // Range one 
    // incentive_won = 0
    // threshold_passed = 0
    // for (var i = 0; i < total_incentives; i ++){
    //     if(total_points > incentive_points[i]){
    //         incentive_won = incentive_earnings[i]
    //         threshold_passed = incentive_points[i]
    //     }
    // }
    money_won = ((monetary_range[1] - monetary_range[0])*total_points/max_points + monetary_range[0]).toFixed(2)
    // total_money_won = +money_won +incentive_won;
    return money_won
}
