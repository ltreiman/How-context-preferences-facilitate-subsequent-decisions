// Need to delete when editing instructions
repeated_times = 2

  function createInstrPage(text){
    return ["<div align=center><div class = 'center_text'; style = 'width: 65vw';>" + text + "<br></div>"]
  }

  // Use when pie chart is involved
  function createInstrPage2(text){
    return ["<div align=center><div class = 'center_text'; style = 'width: 100%';>" + text + "<br></div>"]
  }

  function instructions1(){ 
    ex2 = 20
    ex3 = 65
    p = 0.5 
    p2 = 0.25
    p3 = 0.7
    p4 = 0.4
    p5 = 0.66
    return [
    // Explaining the the pie charts in terms of wins and losses, and starting amount 
    "Welcome to the experiment!<br><br> Please read the instructions carefully in order to understand the task.<br><br>Press <b>next</b> or <b>spacebar</b> to continue.<br><br>",
    "For the first part of the experiment, you will choose between different pairs of gambles from a casino. <br><br> Each trial will give you a certain chance to earn money. Your goal will be to accrue as much money as possible. <br><br> For every $100 you earn from the casino, you will win $1. <br>",
    'At the start of each trial, you will receive money.<br><br>You could receive anywhere from $50 to $100.<br><br>For example, at the beginning of a trial you could receive $64. <br><br>',
    'After you see how much money you received, you will make a choice between two options.<br><br>These options will differ in riskiness. <br><br>',
    'Sometimes, your choice will be between losing a certain amount of your money, or taking a chance to lose none of your money. <br><br> You will now see an example of what this looks like. <br><br>',
    'You will first see how much money you receive: <br><br><h1>You receive $'+ex3+'</h1><br><br>This screen will appear for '+pre_trial_time/1000+' seconds.<br><br>',
    '<u>You will then see two options as displayed below:</u><br><br><br><div class = "safeOptionSquare" style = "float: left; margin-left: 7vw; margin-right: 8vw;"><safeText>Lose<br><br>$'+(ex3*(1-p3)).toFixed(0)+'</safeText></div><div class = "vl"></div><div class="piechart" style=" float: right; background-image: conic-gradient(green '+360*p3+'deg, red 0);"><safeText>Gamble</safeText></div><ul class="legend"><li><span class="keep"></span>Keep All</li><li style = "margin-left:0vw"><span class="lose"></span>Lose All</li></ul><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>In this case, you can either choose to take a guaranteed loss of $'+(ex3*(1-p3)).toFixed(0)+', or take a chance to lose no money at all.<br><br>',
    'Sometimes, your choice will be between keeping a certain amount of your money, or taking a chance to keep all of your money. <br><br> You will now see an example of what this looks like. <br><br>',
    'Again, you will first see how much money you receive from a casino: <br><br><h1>You receive $'+ex2+'</h1>',
    '<u>Again, you will then see two options:</u><br><br><br><br><div class = "safeOptionSquare" style = "float: left; margin-left: 7vw; margin-right: 8vw;"><safeText>Keep<br><br>$'+ex2*p2+'</safeText></div><div class = "vl"></div><div class="piechart" style=" float: right; background-image: conic-gradient(green '+360*p2+'deg, red 0);"><safeText>Gamble</safeText></div><ul class="legend"><li><span class="keep"></span>Keep All</li><li style = "margin-left:0vw"><span class="lose"></span>Lose All</li></ul> <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> In this case, you can either choose to keep $'+ex2*p2+' or take a chance to keep all of it.<br><br>',
    'As you saw in the two examples, the gamble option wil be presented as a <b>colored circle</b>. Here is an example: <br><br><div class="piechart" style="background-image: conic-gradient(green '+360*p+'deg, red 0);"><safeText>Gamble</safeText></div><ul class="legend" style = "float:none"><li style = "margin-left:0vw; margin-right:23vw;"><span class="keep"></span>Keep All</li><li style = "margin-left:0vw;"><span class="lose"></span>Lose All</li></ul><br><br>The <span class = "greenText">green</span> area shows the chance of <b>keeping</b> all your money.<br><br> Similarly, the <span class = "redText">red</span> area shows the chance of <b>losing</b> all your money.<br><br>In this case, there is a 50% chance of keeping all your money and a 50% chance of losing all your money. <br><br>',
    'You will choose between the options using the F and J keys. <br><br>To select the option on the left, press the <b>F key</b>.<br><br>To select the option on the right, press the <b>J key</b>. <br><br>',
    // Time to practice
    '<u>Time to practice!</u> <br><br> You will now perform '+npractice+' practice trials in casino <span class = "greenText" style = "color: '+casino1_practice_color+';">'+casino1_practice_name+'</span>. <br><br>',
    ].map(x => createInstrPage(x))}
  

  function instructions2(){
    return[
        "From now on, you will have to make each choice within "+time_to_choose/1000 +" seconds. <br><br>If you do not choose an option in time, your score for that trial will be 0 points.<br><br>",
        'You are now ready to start experiment. <br><br> You will choose between '+ntrials1+' different pairs of gambles from casino <span class = "greenText" style = "color: '+casino1_color+';">'+casino1_name+'.<br><br>',
        'In order to determine how much money you won, we will select '+noutcome1+' trial from casino <span class = "greenText" style = "color: '+casino1_color+';">'+casino1_name+'</span> at the end of the experiment. The computer will determine how much money you won.<br><br>Since you do not know which trial will be selected, you will have to pay attention on all of them. <br><br>',
        'And again, to encourage you to amass many points, you will win $1 for every $100 you earn from the casino.<br><br>',
    ].map(x => createInstrPage(x))}

  function instructions3(){
      casinoLeft = {name: "Casino A", color: "DarkMagenta"};
      casinoRight = {name: "Casino B", color: "OliveDrab"};
    return[
        'You have completed the first part of the experiment. <br><br> You will now read the instructions for the second, and final, section of the experiment. <br><br>',
        'In the previous trials, you made all your choices in <span class = "greenText" style = "color: '+casino1_color+';">'+casino1_name+'</span>.<br><br>From now on, at the start of each trial you will decide which casino to gamble in.<br><br>',
        '<u>You will see the two casinos as displayed below:</u><br><br><br><br><div class = "safeOptionSquare" style = "float: left; margin-left: 7vw; margin-right: 8vw;"><safeText style = "color: '+casinoLeft.color+';">'+casinoLeft.name+'</safeText></div><div class = "vl" style = "margin-right: 5vw;"></div><div class="safeOptionSquare" style = float: right;"><safeText style = "color: '+casinoRight.color+';">'+casinoRight.name+'</safeText></div><br><br><br><br><br><br><br><br>In this case, you can either choose <span class = "greenText" style = "color: '+casinoLeft.color+';">'+casinoLeft.name+'</span> on the left or <span class = "greenText" style = "color: '+casinoRight.color+';">'+casinoRight.name+'</span> on the right.<br><br>',
        'You will choose between the casinos using the F and J keys. <br><br>To select the casino on the left, press the <b>F key</b>.<br><br>To select the casino on the right, press the <b>J key</b>. <br><br>',
        'Once you select the casino, you will choose between a pair of gambles just like you did in the first part of the experiment. <br><br>The choices will be displayed in the exact same way, so you already know how to select a gamble.<br><br>',
        '<u>Time to practice!</u> <br><br> You will now perform '+npractice+' practice trials.<br><br>',
    ].map(x => createInstrPage(x))}

  // After practice results 
  function instructions4(){
    return[
      "In addition to selecting 1 trial from the first part of the experiment, we will select "+(noutcomes-1)+" trials randomly from the second part of the experiment and resolve them at the end to determine your score. <br><br> For each of these "+(noutcomes)+" trials, the computer will determine how much money you earned.<br><br>Your total amount earned will be the sum of all the outcomes from both sections of the experiment. <br><br>",
      "When choosing between casinos, please avoid simple rules such as alternating back and forth from trial to trial. Instead, try to make a decision on every trial.<br><br>Please note that the name or color of each casino does not affect how much money you could win.<br><br>You may notice differences between casinos. If you develop a preference, you can feel free to choose one casino more than the other.<br><br>",
      "You are now ready to start experiment. <br><br> From now on, you will have to choose a casino within "+time_choose_gamble/1000 +" seconds. If you do not choose a casino in time, a casino will be randomly chosen for you.<br><br>You will also have to choose a gamble within "+time_to_choose/1000 +" seconds, just like in the first part of the experiment. If you do not choose an option in time, your score for that trial will be 0 points.<br><br>",
      "You'll complete "+ntrials+" trials during the study, which will approximately take 25 minutes to complete. <br><br> You will choose between "+num_casino_rounds+" different pairs of casinos, and will be given "+(num_casino_rounds-1)+" short breaks throughout the experiment. <br><br> And again, to encourage you to amass many points, you will win $1 for every $100 you earn from the casinos.<br><br>",
      "You are now ready for the experiment. <br><br>Press space or click the next button to begin! <br><br>"
    ].map(x => createInstrPage(x))}
    




  
