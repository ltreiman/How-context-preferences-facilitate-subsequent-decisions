// Define count object in array
Object.defineProperties(Array.prototype, {
    count: {
        value: function(value) {
            return this.filter(x => x==value).length;
        }
    }
});

// Functions used

// Repeat Casinos

///// Create casino functions: half cartesian and add probabilities

// Use when doing cartesisn product for gain vs gain or loss vs loss due to repeated elements
function half_cartesian(casinos1, casinos2, repeated_times){
    if(repeated_times > 0){
        cart = Array(repeated_times).fill(cartesian(casinos1, casinos2).sort()).flat()
        return cart.filter(function(c){return c[0].name != c[1].name & c[0].name < c[1].name})
    }
    else return []
}


 function add_probabilities(casinos, p_values, repeated_times){
    p_main = Array(casinos.length).fill(p_values).flat()
    results = Array.from(Array(p_main.length), () => new Array(2));
    index = -1
    for (let i = 0; i < results.length; i ++){
        if(i % (repeated_times*p_values.length) == 0){index++}
        temp1 = structuredClone(casinos[index][0]) 
        temp2 = structuredClone(casinos[index][1]) 
        temp1.p = p_main[i]
        temp2.p = p_main[i]
        results[i][0] = temp1
        results[i][1] = temp2
    }
    return results
 } 

 function main_casino_prep(casinos1, casinos2, repeated_times, p_values){
    if (casinos1 == casinos2){ // Gain vs gain or loss vs loss
        main_casinos = half_cartesian(casinos1, casinos2, repeated_times)
    }else{
        main_casinos = Array(repeated_times).fill(cartesian(gain_casinos, loss_casinos).sort()).flat()
    }
    if(main_casinos != []){
        return add_probabilities(main_casinos, p_values, repeated_times)
    }
 }

// Function to repeat: takes an array arr and repeats to the size of len (so want to use total_trials for the number of length)
function repeat(arr, len) {
    while (arr.length < len) arr = arr.concat(arr.slice(0, len-arr.length));
    return arr;
}

function arrayEquals(a, b) {
    return Array.isArray(a) &&
        Array.isArray(b) &&
        a.length === b.length &&
        a.every((val, index) => val === b[index]);
}

// Randomly shuffle the array
function shuffleArray(array, l) {
    for (var i = l - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array
}

function shuffle(arr1, arr2){
    "use strict";
    var l = arr1.length,
    i = 0,
    rnd,
    tmp1,
    tmp2;

    while (i < l) {
        rnd = Math.round(Math.random() * i)
        tmp1 = arr1[i]
        tmp2 = arr2[i]
        arr1[i] = arr1[rnd]
        arr2[i] = arr2[rnd]
        arr1[rnd] = tmp1
        arr2[rnd] = tmp2
        i += 1
    }
    return {array1: arr1, array2: arr2}
}

function cartesian(...args) {
    var r = [], max = args.length-1;
    function helper(arr, i) {
        for (var j=0, l=args[i].length; j<l; j++) {
            var a = arr.slice(0); // clone arr
            a.push(args[i][j]);
            if (i==max)
                r.push(a);
            else
                helper(a, i+1);
        }
    }
    helper([], 0);
    return r;
}



// ********************          UNIFORM DISTRIBUTION    ************************************
//Initialize risky bounds
function initialize_risky_bounds(multipliers, set_risky_bounds){
    risky_bounds = {}
    min_risky_bound = Infinity
    max_risky_bound = -Infinity
    width = set_risky_bounds[1] - (set_risky_bounds[0]+set_risky_bounds[1])/set_risky_bounds.length
    for (let i = 0; i < multipliers.length; i++){
        avg_risky_bounds = Math.round(multipliers[i]*(set_risky_bounds[0]+set_risky_bounds[1])/set_risky_bounds.length,0)
        risky_bounds[multipliers[i]] = [avg_risky_bounds - width, avg_risky_bounds + width]
        if((avg_risky_bounds - width) < min_risky_bound){
            min_risky_bound = (avg_risky_bounds - width)
        }
        if((avg_risky_bounds + width) > max_risky_bound){
            max_risky_bound = (avg_risky_bounds + width)
        }
    }
    return risky_bounds
}

function draw_from_uniform_distribution(risky_bounds){
    return Math.random()*(risky_bounds[1]-risky_bounds[0])+ risky_bounds[0]

}

// ********************  NORMAL DISTRIBUTION    ************************************

// Helper function to convert prob to z score
Z_MAX = 6 
function poz(z) {

    var y, x, w;

    if (z == 0.0) {
        x = 0.0;
    } else {
        y = 0.5 * Math.abs(z);
        if (y > (Z_MAX * 0.5)) {
            x = 1.0;
        } else if (y < 1.0) {
            w = y * y;
            x = ((((((((0.000124818987 * w
                     - 0.001075204047) * w + 0.005198775019) * w
                     - 0.019198292004) * w + 0.059054035642) * w
                     - 0.151968751364) * w + 0.319152932694) * w
                     - 0.531923007300) * w + 0.797884560593) * y * 2.0;
        } else {
            y -= 2.0;
            x = (((((((((((((-0.000045255659 * y
                           + 0.000152529290) * y - 0.000019538132) * y
                           - 0.000676904986) * y + 0.001390604284) * y
                           - 0.000794620820) * y - 0.002034254874) * y
                           + 0.006549791214) * y - 0.010557625006) * y
                           + 0.011630447319) * y - 0.009279453341) * y
                           + 0.005353579108) * y - 0.002141268741) * y
                           + 0.000535310849) * y + 0.999936657524;
        }
    }
    return z > 0.0 ? ((x + 1.0) * 0.5) : ((1.0 - x) * 0.5);
}
// Calculate prob to z score
function critz(p){
    var Z_EPSILON = 0.000001;     /* Accuracy of z approximation */
    var minz = -Z_MAX;
    var maxz = Z_MAX;
    var zval = 0.0;
    var pval;
    if( p < 0.0 ) p = 0.0;
    if( p > 1.0 ) p = 1.0;

    while ((maxz - minz) > Z_EPSILON) {
        pval = poz(zval);
        if (pval > p) {
            maxz = zval;
        } else {
            minz = zval;
        }
        zval = (maxz + minz) * 0.5;
    }
    return(zval);
}

// Calculate standard deviation
function calc_sd(multipliers, noise){
    if(multipliers.length == 1){
        return sd = 1
    } else{
        return (((multipliers[1]+multipliers[0])/2) - multipliers[0])/critz(1-noise) 
    }
}

function boxMullerTransform() {
    const u1 = Math.random();
    const u2 = Math.random();
    
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);
    
    return { z0, z1 };
}

function getNormallyDistributedRandomNumber(mean, stddev) {
    const { z0, _ } = boxMullerTransform();
    
    return z0 * stddev + mean;
}

// FUNCTION: Convert points to monetary value
// Inputs: 
// Total_points: (integer) number of points the particpant earned
// Max_points: (integer) max number of points particpant could have earned
// Monetary Range: (2x1 vector) of lowest and highest amount of money to win possible
// Incentive Earnings: (2x1 vector) additional money won if above certain threshold
// Incentive Points: (2x1 vector) thresholds needed to win incentive earnings
// Total_incentives: integer of the number possible incentives. This is equivalent to the length of the incentive earnings array and points array
// Output: Vector [Monetary amount of points won, incentive won, incentive + money won, threshold passed to win points]
function convert_monetary_value(total_points){
    // Range one 
    // incentive_won = 0
    // threshold_passed = 0
    // for (var i = 0; i < total_incentives; i ++){
    //     if(total_points > incentive_points[i]){
    //         incentive_won = incentive_earnings[i]
    //         threshold_passed = incentive_points[i]
    //     }
    // }
    money_won = total_points / 100
    // money_won = ((monetary_range[1] - monetary_range[0])*total_points/max_points + monetary_range[0]).toFixed(2)
    // total_money_won = +money_won +incentive_won;
    return money_won
}
